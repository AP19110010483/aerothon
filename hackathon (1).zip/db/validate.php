<?php
$servername = "localhost";
$password = "";
$dbname="airbus";

// Create connection
$conn = new mysqli($servername, $password,$dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

    $name=$_POST["item-name"];
    $id=$_POST["item-id"];
    $raw_mat=$_POST["raw-materials"];
    $quantity=$_POST["quantity"];
    $indate=$_POST["indate"];
    $outdate=$_POST["outdate"];
    //inserting data into database
    $sql="Insert into ' fabrication' ('item-name','item-id','raw-materials','quantity','indate','outdate')
    values('$name','$id','$raw_mat','$quantity','$indate','$outdate')";
    $rs = mysqli_query($conn, $sql);
    if($rs){
        echo "Data Inserted Successfully";
    }
    $conn->close();

?>
