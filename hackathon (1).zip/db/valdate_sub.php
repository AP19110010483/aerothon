<?php
$servername = "localhost";
$password = "";
$dbname="airbus";

// Create connection
$conn = new mysqli($servername, $password,$dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

    $ais=$_POST["assembly-id"];
    $process=$_POST["process"];
    $item-id=$_POST["item-id"];
    $mac-id=$_POST["machine-id"];
    $sdate=$_POST["start-date"];
    $edate=$_POST["end-date"];
    //inserting data into database
    $sql="Insert into 'assembly ('assembly-id','process','item-id','machine-id','start-date','end-date')
    values('$ais','$process','$item','$mac','$sdate','$edate')";
    $rs = mysqli_query($conn, $sql);
    if($rs){
        echo "Data Inserted Successfully";
    }
    $conn->close();

?>
